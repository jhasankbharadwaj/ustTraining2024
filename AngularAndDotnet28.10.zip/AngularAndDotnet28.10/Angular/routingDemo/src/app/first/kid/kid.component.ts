import { Component } from '@angular/core';

@Component({
  selector: 'app-kid',
  standalone: true,
  imports: [],
  templateUrl: './kid.component.html',
  styleUrl: './kid.component.css'
})
export class KidComponent {

}
