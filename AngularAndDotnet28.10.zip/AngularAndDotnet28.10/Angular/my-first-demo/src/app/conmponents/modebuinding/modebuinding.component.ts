import { Component } from '@angular/core';

@Component({
  selector: 'app-modebuinding',
  standalone: true,
  imports: [],
  templateUrl: './modebuinding.component.html',
  styleUrl: './modebuinding.component.css'
})
export class ModebuindingComponent {
  Name:string="jhasank";
  age:number=20;
  exp:any=2;

}
