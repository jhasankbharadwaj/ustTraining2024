export class User {
    

     constructor(
        public username: string,
        public email: string,
        public password: string,
        public role: string,
        public terms: boolean
      ) {}
}
