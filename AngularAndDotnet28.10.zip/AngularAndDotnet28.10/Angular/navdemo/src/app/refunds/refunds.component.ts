import { Component } from '@angular/core';

@Component({
  selector: 'app-refunds',
  standalone: true,
  imports: [],
  templateUrl: './refunds.component.html',
  styleUrl: './refunds.component.css'
})
export class RefundsComponent {

}
