import { Routes } from '@angular/router';
import { MenuComponent } from './menu/menu.component';
import { OrderComponent } from './order/order.component';
import { RefundsComponent } from './refunds/refunds.component';
import { ContactComponent } from './contact/contact.component';

export const routes: Routes = [
    {path:"menu",component:MenuComponent},
    {path:"order",component:OrderComponent},
    {path:"refunds",component:RefundsComponent},
    {path:"contact",component:ContactComponent},

];
