import { Waitinglist } from './waitinglist';

describe('Waitinglist', () => {
  it('should create an instance', () => {
    expect(new Waitinglist()).toBeTruthy();
  });
});
