
export class Product {

    Id:number;
    Image:string;
    Name:string;
    Model:string;
    Price?:number;

}
