
export class Waitinglist {
    Name:string;
    Price:number;
    WP:number;
}
