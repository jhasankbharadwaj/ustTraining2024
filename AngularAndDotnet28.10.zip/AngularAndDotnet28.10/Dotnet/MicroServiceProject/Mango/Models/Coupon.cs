﻿namespace Mango.Models
{
    public class Coupon
    {
    }
}
