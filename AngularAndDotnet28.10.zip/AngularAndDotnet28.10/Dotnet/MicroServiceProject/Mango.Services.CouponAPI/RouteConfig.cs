﻿namespace Mango.Services.CouponAPI
{
    public class RouteConfig
    {
    }
}
